import { type RouteConfig, index, route } from '@react-router/dev/routes';

export default [
	index('routes/home.tsx'),
    route('contact', 'routes/contact.tsx'),
    route('booking', 'routes/booking.tsx'),
    route('booking/:handle', 'routes/booking.$handle.tsx'),
    route('gallery', 'routes/gallery.tsx'),
    route('news', 'routes/news.tsx'),
    route('news/:slug', 'routes/news.$slug.tsx'),
    route('privacy', 'routes/privacy.tsx'),
    route('checkout/success', 'routes/checkout.success.tsx'),
    route('checkout/cancelled', 'routes/checkout.cancelled.tsx'),
    route('llms.txt', 'routes/llms.txt.ts'),
    route('rss.xml', 'routes/rss.xml.ts'),
    
	route('sitemap.xml', 'routes/sitemap.xml.ts'),
	route('robots.txt', 'routes/robots.txt.ts'),
	route('api/health', 'routes/api.health.ts'),
	route('api/*', 'routes/api.$.ts'),
] satisfies RouteConfig;
