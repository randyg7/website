import type { Route } from './+types/llms.txt';
import { siteOrigin } from '@/lib/site-origin.server';
import { pocketbasePublic } from '@/lib/pocketbase-public.server';
export async function loader({request}:Route.LoaderArgs){const origin=siteOrigin(request);const {items}=await pocketbasePublic(request).listRecords<{slug:string;title:string;excerpt:string}>('news_posts',{perPage:200});return new Response(`# Junk removal\n\n> Job enquiries, appointment requests and helpful removal guides.\n\n## Pages\n- [Request a removal](${origin}/booking)\n- [Contact](${origin}/contact)\n- [Journal](${origin}/news)\n${items.map(p=>`- [${p.title}](${origin}/news/${p.slug}): ${p.excerpt}`).join('\n')}\n`,{headers:{'Content-Type':'text/plain; charset=utf-8'}});}
