import type { Route } from './+types/sitemap.xml';
import { siteOrigin } from '@/lib/site-origin.server';
import { pocketbasePublic } from '@/lib/pocketbase-public.server';
import { getProducts } from '@/api/ecommerce-api';

type SitemapEntry = {
	path: string;
	lastmod?: string;
};

const STATIC_PATHS = ['/', '/contact', '/booking', '/gallery', '/news', '/privacy'];

function escapeXml(value: string): string {
	return value
		.replaceAll('&', '&amp;')
		.replaceAll('<', '&lt;')
		.replaceAll('>', '&gt;')
		.replaceAll('"', '&quot;')
		.replaceAll("'", '&apos;');
}

function toLoc(origin: string, path: string): string {
	return `${origin}${path.startsWith('/') ? path : `/${path}`}`;
}

function serializeSitemap(origin: string, entries: SitemapEntry[]): string {
	const urls = entries
		.map(entry => {
			const loc = escapeXml(toLoc(origin, entry.path));
			const lastmod = entry.lastmod
				? `\n\t\t<lastmod>${escapeXml(entry.lastmod)}</lastmod>`
				: '';

			return `\t<url>\n\t\t<loc>${loc}</loc>${lastmod}\n\t</url>`;
		})
		.join('\n');

	return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`;
}

/**
 * Public dynamic URLs (blog posts, PDPs, articles).
 * Return `{ path, lastmod }` in the same change that adds a collection.
 * Return `[]` only while the site has no public records; clear those URLs
 * again in the same change that removes the collection.
 */
async function getDynamicEntries(request: Request): Promise<SitemapEntry[]> {
    const pb = pocketbasePublic(request);
    const entries: SitemapEntry[] = [];
    for (let page = 1; ; page++) {
        const posts = await pb.listRecords<{slug: string; updated: string}>('news_posts', {page, perPage: 200});
        entries.push(...posts.items.map(p => ({path: `/news/${p.slug}`, lastmod: p.updated})));
        if (page >= posts.totalPages) break;
    }
    let offset = 0;
    for (;;) {
        const {products,count} = await getProducts({type:'booking', exclude_types:'subscription', limit:2000, offset});
        entries.push(...products.filter(p=>!p.seo.noindex).map(p=>({path:`/booking/${p.url_handle}`,lastmod:p.updated_at || undefined})));
        offset += products.length;
        if (!products.length || offset >= count) break;
    }
    return entries;
}

export async function loader({ request }: Route.LoaderArgs) {
	const origin = siteOrigin(request);
	const entries: SitemapEntry[] = [
		...STATIC_PATHS.map(path => ({ path })),
		...(await getDynamicEntries(request)),
	];

	return new Response(serializeSitemap(origin, entries), {
		headers: {
			'Content-Type': 'application/xml; charset=utf-8',
			'Cache-Control': 'public, max-age=3600',
		},
	});
}
