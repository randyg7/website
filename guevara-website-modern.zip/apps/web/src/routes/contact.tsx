import type { Route } from './+types/contact';
import { seo } from '@/lib/seo';
import { images } from '@/constants/images';
import { EnquiryForm } from '@/components/enquiry-form';
export function meta({matches,location}:Route.MetaArgs){return seo({matches,location},{title:'Tell us about your job — Junk removal',description:'Request a junk removal quote. Share your job details, location and access information so your removal can be planned before an appointment is confirmed.',image:images.truck});}
export default function Contact(){return <main className="page-rail"><p className="eyebrow">LET’S TALK ABOUT YOUR JOB</p><h1>What needs<br/><span>to go?</span></h1><p className="page-intro">A clearer space starts with a few details. Send your enquiry below.</p><EnquiryForm/></main>;}
