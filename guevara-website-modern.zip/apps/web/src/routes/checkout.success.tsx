import type { Route } from './+types/checkout.success';
import { seo } from '@/lib/seo';
import { CheckoutResult } from '@/components/checkout-result';
export function meta({matches,location}:Route.MetaArgs){return seo({matches,location},{title:'Thank you — Junk removal',description:'You have returned from the booking checkout. Check your checkout confirmation for your payment and appointment details.',noindex:true});}
export default function Success(){return <CheckoutResult success/>;}
