import type { Route } from './+types/gallery';
import { seo } from '@/lib/seo';
import { images } from '@/constants/images';
import { Gallery } from '@/components/gallery';
import { ContactCallout } from '@/components/home/contact-callout';
export function meta({matches,location}:Route.MetaArgs){return seo({matches,location},{title:'Making space — Junk removal gallery',description:'See the hauling truck and trailer, then tell us what you would like removed from your space.',image:images.work});}
export default function GalleryPage(){return <main><div className="page-rail short"><p className="eyebrow">THE GALLERY</p><h1>Picture a<br/><span>clearer space.</span></h1></div><Gallery/><ContactCallout/></main>;}
