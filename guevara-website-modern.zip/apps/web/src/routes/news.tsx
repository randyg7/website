import type { Route } from './+types/news';
import { seo } from '@/lib/seo';
import { pocketbasePublic } from '@/lib/pocketbase-public.server';
import { images } from '@/constants/images';
import { NewsFeed, type NewsPost } from '@/components/news-feed';
import { Newsletter } from '@/components/newsletter';
export async function loader({request}:Route.LoaderArgs){const pb=pocketbasePublic(request);const {items}=await pb.listRecords<NewsPost>('news_posts',{sort:'-created',perPage:100});return {posts:items};}
export function meta({matches,location}:Route.MetaArgs){return seo({matches,location},{title:'The clear-space journal — Junk removal',description:'Straightforward guides for planning a junk removal, preparing your space and sending a useful job enquiry. Read the latest removal tips and updates.',image:images.work,jsonLd:{'@context':'https://schema.org','@type':'CollectionPage',name:'The clear-space journal'}});}
export default function News({loaderData}:Route.ComponentProps){return <main><div className="page-rail"><p className="eyebrow">THE JOURNAL</p><h1>A little know-how.<br/><span>A lot less junk.</span></h1><NewsFeed posts={loaderData.posts}/></div><Newsletter/></main>;}
