import type { Route } from './+types/home';
import { seo } from '@/lib/seo';
import { images } from '@/constants/images';
import { Hero } from '@/components/home/hero';
import { Services } from '@/components/home/services';
import { Gallery } from '@/components/gallery';
import { ContactCallout } from '@/components/home/contact-callout';
import { Newsletter } from '@/components/newsletter';
export function meta({ matches, location }: Route.MetaArgs) { return seo({ matches, location }, {title:'Junk removal — Less junk. More space.',description:'Make room for what matters. Tell us about your junk removal job, request a preferred appointment date and confirm your removal details before payment.',image:images.truck,jsonLd:[{'@context':'https://schema.org','@type':'WebSite',name:'Junk removal'},{'@context':'https://schema.org','@type':'Organization',name:'Junk removal'}]}); }
export default function HomePage() { return <main><Hero/><Services/><Gallery preview/><ContactCallout/><Newsletter/></main>; }
