import type { Route } from './+types/booking.$handle';
import { EcommerceApiError, getProductByHandle, toPriceUnits } from '@/api/ecommerce-api';
import { seo } from '@/lib/seo';
import { BookingPanel } from '@/components/booking-panel';
import { Reviews } from '@/components/reviews';
export async function loader({params}:Route.LoaderArgs){try{const product=await getProductByHandle(params.handle);if(product.type.value!=='booking')throw new Response('Not found',{status:404});return {product};}catch(e){if(e instanceof EcommerceApiError && e.status===404)throw new Response('Not found',{status:404});throw e;}}
export function meta({matches,location,loaderData}:Route.MetaArgs){const p=loaderData?.product;return seo({matches,location},p ? {title:p.seo.title,description:p.seo.description,image:p.seo.image,noindex:p.seo.noindex,jsonLd:{'@context':'https://schema.org','@type':'Product',name:p.title,description:p.seo.description,offers:{'@type':'Offer',price:toPriceUnits(p.price_in_cents,p.currency_info),priceCurrency:p.currency.toUpperCase()}}} : {title:'Appointment not found',description:'This appointment is no longer available.',noindex:true});}
export default function Appointment({loaderData}:Route.ComponentProps){return <main className="page-rail"><p className="eyebrow">CHOOSE YOUR REMOVAL TIME</p><h1>Make it<br/><span>a date.</span></h1><BookingPanel product={loaderData.product}/><Reviews product={loaderData.product}/></main>;}
