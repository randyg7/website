import type { Route } from './+types/news.$slug';
import { pocketbasePublic } from '@/lib/pocketbase-public.server';
import { seo } from '@/lib/seo';
import { images } from '@/constants/images';
import type { NewsPost } from '@/components/news-feed';
import { NewsArticle } from '@/components/news-article';
export async function loader({request,params}:Route.LoaderArgs){const pb=pocketbasePublic(request);const post=await pb.findFirstRecord<NewsPost>('news_posts',pb.filter('slug = {:slug}',{slug:params.slug}));if(!post)throw new Response('Not found',{status:404});return {post};}
export function meta({matches,location,loaderData}:Route.MetaArgs){const p=loaderData?.post;return seo({matches,location},p?{title:p.title,description:p.excerpt,image:images.work,type:'article',jsonLd:{'@context':'https://schema.org','@type':'Article',headline:p.title,description:p.excerpt,image:images.work}}:{title:'Guide not found',description:'This guide is no longer available.',noindex:true});}
export default function Post({loaderData}:Route.ComponentProps){return <main><NewsArticle post={loaderData.post}/></main>;}
