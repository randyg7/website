import type { Route } from './+types/privacy';
import { seo } from '@/lib/seo';
import { PrivacyContent } from '@/components/privacy-content';
export function meta({matches,location}:Route.MetaArgs){return seo({matches,location},{title:'Privacy & your information — Junk removal',description:'Learn how your job enquiry and email sign-up information is used, how booking payments are handled and how to manage optional cookies on this website.'});}
export default function Privacy(){return <PrivacyContent/>;}
