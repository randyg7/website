import type { Route } from './+types/checkout.cancelled';
import { seo } from '@/lib/seo';
import { CheckoutResult } from '@/components/checkout-result';
export function meta({matches,location}:Route.MetaArgs){return seo({matches,location},{title:'Checkout cancelled — Junk removal',description:'Checkout was cancelled. Nothing was charged in this checkout attempt; return to booking to select another appointment.',noindex:true});}
export default function Cancelled(){return <CheckoutResult/>;}
