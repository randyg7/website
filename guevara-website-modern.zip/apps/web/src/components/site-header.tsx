import { NavLink, Link } from 'react-router';
import { Phone, Menu, X } from 'lucide-react';
import { images } from '@/constants/images';
import { business } from '@/constants/business';
import { telHref } from '@/lib/contact-links';
import { useDisclosure } from '@/hooks/use-disclosure';
export function SiteHeader() {
 const menu = useDisclosure();
 return <header className="site-header"><Link to="/" className="wordmark" aria-label="Guevara Hauling and Junk Removal home"><img className="brand-logo" src={images.logo} alt="Guevara Hauling & Junk Removal"/></Link><nav className="desktop-nav" aria-label="Main navigation"><NavLink to="/#services">The service</NavLink><NavLink to="/gallery">Gallery</NavLink><NavLink to="/news">Journal</NavLink><NavLink to="/contact">Contact</NavLink></nav><a className="button small" href={telHref(business.phone)}>Call now <Phone size={16}/></a><button className="menu-button" {...menu.triggerProps} aria-label="Toggle navigation">{menu.isOpen ? <X/> : <Menu/>}</button>{menu.isOpen && <nav className="mobile-nav" {...menu.panelProps} aria-label="Mobile navigation"><Link onClick={menu.close} to="/#services">The service</Link><Link to="/gallery">Gallery</Link><Link to="/news">Journal</Link><Link to="/contact">Contact</Link></nav>}</header>;
}
