import { Link } from 'react-router';
import { ArrowUpRight, Phone, MapPin } from 'lucide-react';
import { images } from '@/constants/images';
import { business } from '@/constants/business';
import { telHref } from '@/lib/contact-links';

const hauls = ['Furniture', 'Appliances', 'Mattresses', 'Yard waste', 'Construction debris', 'Garage cleanouts', 'Old electronics', 'Whole-house cleanouts'];

export function Hero() {
	return (
		<>
			<section className="hero">
				<div className="hero-copy">
					<p className="hero-place"><MapPin size={16}/> Junk removal in {business.area}</p>
					<h1>Big on removal.<br/><span>Small on hassle.</span></h1>
					<p className="hero-description">Tell us what needs to go and where it is. We follow up fast, agree the price before we lift anything, and haul it away.</p>
					<div className="hero-actions">
						<Link className="button" to="/contact">Get a job quote <ArrowUpRight size={20}/></Link>
						<a className="button outline-light" href={telHref(business.phone)}><Phone size={18}/> {business.phoneDisplay}</a>
					</div>
				</div>
				<div className="truck-stage">
					<img src={images.truck} fetchPriority="high" alt="White pickup truck and black hydraulic dump trailer"/>
					<div className="space-stamp">Less junk.<br/><strong>More space.</strong></div>
				</div>
			</section>
			<div className="haul-band" aria-label="What we haul">
				<div className="haul-track" aria-hidden="true">
					{[0, 1].map(n => <ul key={n}>{hauls.map(h => <li key={h}>{h}</li>)}</ul>)}
				</div>
				<p className="sr-only">We haul {hauls.join(', ')}.</p>
			</div>
		</>
	);
}
