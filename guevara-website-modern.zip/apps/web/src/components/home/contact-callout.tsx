import { Link } from 'react-router';
import { ArrowUpRight, Phone } from 'lucide-react';
import { business } from '@/constants/business';
import { telHref } from '@/lib/contact-links';
export function ContactCallout() { return <section className="contact-callout"><h2>Let’s get it<br/>out of your way.</h2><div className="callout-actions"><Link className="button light" to="/contact">Get a job quote <ArrowUpRight size={22}/></Link><a className="callout-phone" href={telHref(business.phone)}><Phone size={22}/> {business.phoneDisplay}</a></div></section>; }
