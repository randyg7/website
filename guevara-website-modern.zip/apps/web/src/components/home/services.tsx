import { Link } from 'react-router';
import { ArrowUpRight, Sofa, Refrigerator, BedDouble, TreePine, Hammer, Package, Warehouse, Trash2 } from 'lucide-react';

const items = [
	{ icon: Sofa, name: 'Furniture', note: 'Couches, tables, dressers, desks' },
	{ icon: Refrigerator, name: 'Appliances', note: 'Fridges, washers, dryers, stoves' },
	{ icon: BedDouble, name: 'Mattresses', note: 'Beds, box springs, frames' },
	{ icon: TreePine, name: 'Yard waste', note: 'Branches, brush, old fencing' },
	{ icon: Hammer, name: 'Construction debris', note: 'Drywall, lumber, flooring' },
	{ icon: Package, name: 'Garage cleanouts', note: 'Boxes, tools, storage clutter' },
	{ icon: Trash2, name: 'General junk', note: 'Whatever is in your way' },
	{ icon: Warehouse, name: 'Full cleanouts', note: 'Rooms, units, whole properties' },
];

export function Services() {
	return (
		<section className="service-section" id="services">
			<div className="service-heading">
				<h2>If it’s in the way,<br/><span>we haul it.</span></h2>
				<div>
					<p>We load, haul and dispose. You point at it, we take it. Not sure if we take something? Ask.</p>
					<Link className="text-link" to="/contact">Tell us what needs to go <ArrowUpRight size={20}/></Link>
				</div>
			</div>
			<ul className="haul-grid">
				{items.map(({ icon: Icon, name, note }) => (
					<li key={name}><Icon size={30} strokeWidth={1.75}/><h3>{name}</h3><p>{note}</p></li>
				))}
			</ul>
			<ol className="process">
				<li><span>1</span><h3>Show us the job.</h3><p>Describe the junk, where it is and how we can get to it.</p></li>
				<li><span>2</span><h3>Agree the price.</h3><p>We confirm the scope, the date and the price before any work starts.</p></li>
				<li><span>3</span><h3>Get your space back.</h3><p>We arrive, load up and haul it away.</p></li>
			</ol>
		</section>
	);
}
