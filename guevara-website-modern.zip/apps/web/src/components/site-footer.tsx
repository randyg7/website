import { Link } from 'react-router';
import { ArrowUpRight } from 'lucide-react';
import { openCookiePreferences } from '@/lib/cookie-consent';
export function SiteFooter() { return <footer className="site-footer"><div className="footer-top"><Link className="wordmark" to="/">Junk removal.</Link><p>Less junk. More space.</p><Link to="/contact">Let’s talk about your job <ArrowUpRight size={18}/></Link></div><div className="footer-bottom"><span>© 2026 Junk removal</span><Link to="/booking">Booking & payment</Link><Link to="/privacy">Privacy</Link><button onClick={openCookiePreferences}>Cookie settings</button></div></footer>; }
