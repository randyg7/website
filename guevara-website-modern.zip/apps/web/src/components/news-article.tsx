import { Link } from 'react-router';
import type { NewsPost } from '@/components/news-feed';
export function NewsArticle({post}:{post:NewsPost}){return <article className="page-rail article"><Link className="text-link" to="/news">← Back to the journal</Link><p className="eyebrow">REMOVAL GUIDE</p><h1>{post.title}</h1><p className="page-intro">{post.excerpt}</p><div className="article-body">{post.body.split('\n\n').map((p,i)=><p key={i}>{p}</p>)}</div><Link className="button" to="/contact">Tell us about your removal ↗</Link></article>;}
