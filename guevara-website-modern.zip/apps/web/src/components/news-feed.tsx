import { Link } from 'react-router';
export type NewsPost={id:string;slug:string;title:string;excerpt:string;body:string;updated:string;created:string};
export function NewsFeed({posts}:{posts:NewsPost[]}){return <section className="news-feed">{posts.length ? posts.map((p,i)=><Link key={p.id} to={`/news/${p.slug}`}><span className="section-label">GUIDE / {String(i+1).padStart(2,'0')}</span><div><h2>{p.title}</h2><p>{p.excerpt}</p></div><span className="news-arrow">↗</span></Link>) : <p>There are no updates yet. Check back soon.</p>}</section>;}
