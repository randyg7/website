import { Link } from 'react-router';
import { useEffect } from 'react';
import { useCart } from '@/hooks/use-ecommerce-cart';
export function CheckoutResult({success=false}:{success?:boolean}){const {clear,isLoading}=useCart();useEffect(()=>{if(success && !isLoading)clear();},[success,isLoading,clear]);return <main className="page-rail"><p className="eyebrow">BOOKING & PAYMENT</p><h1>{success?'Thank you.':'No problem.'}</h1><p className="page-intro">{success?'You’re back from checkout. Please check your checkout confirmation and receipt for your payment and appointment details.':'Checkout was cancelled. Nothing was charged in this attempt. You can return to booking when you’re ready.'}</p><Link className="button" to="/booking">Back to booking ↗</Link></main>;}
