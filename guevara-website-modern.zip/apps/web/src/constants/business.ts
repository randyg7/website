/**
 * Business contact details. Update `phone` with the real number once known.
 */
export const business = {
	/** Full international form, e.g. `+1 555 010 1234`. */
	phone: '+1 562 737 7676',
	phoneDisplay: '562-737-7676',
	area: 'Long Beach, CA and nearby',
};
