export const images = {
  truck: 'https://horizons-cdn.hostinger.com/49c4c07b-33a1-4457-a3cd-429d86589530/a7ff9a43cd36cee54712f50758345ef8.jpg',
  work: 'https://horizons-cdn.hostinger.com/49c4c07b-33a1-4457-a3cd-429d86589530/2943d7376c95e51d09d6c23259ebf9e3.jpg',
  space: 'https://horizons-cdn.hostinger.com/49c4c07b-33a1-4457-a3cd-429d86589530/a7ff9a43cd36cee54712f50758345ef8.jpg',
  logo: 'https://horizons-cdn.hostinger.com/49c4c07b-33a1-4457-a3cd-429d86589530/babd7cd226c7744b4b450f2c857facb7.png'
};
export const imageSet = (url: string) => `${url}?width=375 375w, ${url}?width=768 768w, ${url}?width=1024 1024w`;
